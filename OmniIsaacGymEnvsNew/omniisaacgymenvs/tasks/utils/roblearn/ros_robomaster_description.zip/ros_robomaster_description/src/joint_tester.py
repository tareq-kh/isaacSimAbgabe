#!/usr/bin/env python3
import rospy
import sys, os
import tf
import sensor_msgs.msg as sensor_msgs

import sys

from math import sin,cos,pi
from geometry_msgs.msg import Twist
from robomaster_s1_msgs.msg import LedAction
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Twist
from sensor_msgs.msg import JointState


class joint_tester(object):
    
    def __init__(self):

        rospy.loginfo("Starting Robomaster Controller Version 2")
        rospy.loginfo(sys.version)

        # Rospyrate
        self.rate = rospy.Rate(50)

        ## Joint State Publisher 
        self.joint_pub             = rospy.Publisher("/robomaster/wheel_joint_states", JointState, queue_size=4)
    
     
        self.rate.sleep()


  
    ## Update all  joints input is in degree 
    def update_joint(self,angle_degree):
        rospy.loginfo("Update Joints")
        msg = JointState()
        msg.header.frame_id="Robomaster_wheels"
        current_time=rospy.Time.now()
        msg.header.stamp=current_time
        #msg.name = ['Wheel_fr_joint']   ## Joint Name 
        ##angle is in rad
        ## degree to rad 
        current_time=rospy.Time.now()
        msg.header.stamp=current_time
        msg.velocity = []
        msg.effort = []

        for x in [['Wheel_fr_joint',0],['Wheel_fl_joint',0],['Wheel_rr_joint',0],['Wheel_rl_joint',0]]:
            msg.name = [x[0]]
            current_time=rospy.Time.now()
            msg.header.stamp=current_time
            angle=angle_degree*(pi/180)
            msg.position = [angle] 
            self.joint_pub.publish(msg)  
                            
  
  
        

    ## This will Run with the defined ROS Rate ans send Updates to the Motors.
    def talker(self):
        angle_degree=0       
        while not rospy.is_shutdown():
            
            self.update_joint(angle_degree)
            angle_degree=angle_degree+7.2
            self.rate.sleep()


if __name__ == '__main__':
    
    rospy.init_node('talker', anonymous=True)
    my_node = joint_tester()
    
    try:
        my_node.talker()
    except rospy.ROSInterruptException:
        pass

        
